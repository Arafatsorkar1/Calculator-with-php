<?php
require_once 'vendor/autoload.php';

use App\classes\FullName;
use App\classes\Calculator;



if (isset($_GET['page']))
{

    if ($_GET['page'] == 'home')
    {

        include 'pages/Home.php';
    }

    elseif ($_GET['page'] == 'get-full-name')
    {

        $fulName= new \App\classes\FullName($_POST);
        $result = $fulName->index();

        include 'pages/Home.php';
    }

    elseif ($_GET['page'] == 'full-name')
    {
        include 'pages/fullName.php';
    }

    elseif ($_GET['page'] == 'calculator')
    {
        include 'pages/calculator.php';
    }

    elseif($_GET['page'] == 'calculator-result')
    {
        $calculator = new Calculator($_POST);
        $result = $calculator->index();
        include 'pages/calculator.php';
    }
}


