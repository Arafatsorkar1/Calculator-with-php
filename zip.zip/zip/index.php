<?php

require_once 'vendor/autoload.php';
use App\classes\Homepage;
$homepage = new Homepage();
$homepage->index();